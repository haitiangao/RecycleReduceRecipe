package com.example.recyclereducerecipe.model;

import java.util.ArrayList;

public class Recipe {

    private String recipeName;
    private String recipeIngredients;

    public Recipe(String name) {
        this.recipeName = recipeName;
        this.recipeIngredients = recipeIngredients;
    }

    public String getRecipeName() {
        return recipeName;
    }

    public void setRecipeName(String recipeName) {
        this.recipeName = recipeName;
    }

    public String getRecipeIngredients() {
        return recipeIngredients;
    }

    public void setRecipeIngredients(ArrayList<String> recipeIngredients) {
        ArrayList<Recipe> recipeList = new ArrayList<Recipe>();
        return;

    }
}
